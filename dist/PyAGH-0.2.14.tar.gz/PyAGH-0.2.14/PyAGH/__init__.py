from .amatrix import makeA
from .gmatrix import makeG
from .hmatrix import makeH
from .sort import sortPed
from .loaddata import loadEgPed, loadEgGeno
from .selectped import selectPed
from .plot import cluster, heat,gragh, pca
from .coef import coefKinship,coefInbreeding